# swing-notification
Date : 21/01/2022<br/>
How to coding in java
visit my youtube : https://www.youtube.com/c/HelloWorld-Raven/featured
<br/><br/>

![sample](https://user-images.githubusercontent.com/58245926/150556153-328f9da9-1b6c-4d49-8b17-bfa21772e4ce.jpg)
