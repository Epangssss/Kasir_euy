package barcode.view;

/**
 *
 * @author Lenovo
 */
class BarcodeException {
    
}
